<!--登录注册页的公共-->
<div class="navbox">
	<div class="navbg">
		<div class="logo">
			<h1 class="fl">
			<a href="">
				<img src="http://www.xiangqu.com/build/xiangqu/images/login_logo.jpg"/>
			</a></h1>
		</div>
	</div>
</div>