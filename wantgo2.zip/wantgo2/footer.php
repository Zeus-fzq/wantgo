<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title></title>
		<link rel="stylesheet" type="text/css" href="css/footer.css"/>
	</head>

	<body>
		<div class="footer">
			<div class="footerwrap">
				<div class="footerlogin"></div>
				<div class="footerp">
					<p>"上帝存在于细节中。"</p>
					<p>by 密斯·凡德罗</p>
				</div>
				<div class="footerlink">

				</div>
			</div>
		</div>
		<div class="download">
			<div class="close"></div>
			<a class="rz"></a>
			<p>想去APP下载</p>
			<div class="ewm"></div>
		</div>
		<div class="jy"></div>
		<div class="backtop"></div>
	</body>
	<script src="js/jquery-3.1.1.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/footer.js" type="text/javascript" charset="utf-8"></script>
	
</html>